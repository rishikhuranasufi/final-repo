package com.learn.tdd.helper;

public class Common {
    public static final String FUTURE_EFFECTIVE_PATTERN = "[a-zA-Z]*";
    public static final String MODEL_NAME_PATTERN = "([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*";
}
