package com.learn.tdd.service;

import com.learn.tdd.dao.SettlementInstructionDAO;
import com.learn.tdd.exception.IssueWhileExecutingQuery;
import com.learn.tdd.vo.SettlementInstruction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component(value = "settlementInstructionBusinessImpl")
public class SettlementInstructionBusinessImpl {

    public static final String DATE_FORMATTER = "uuuu-M-d";
    public static final String DATE_FORMATTER_02 = "uuuu-MM-dd";

    public SettlementInstructionBusinessImpl(SettlementInstructionDAO settlementInstructionDAO,
                                             SendNotification sendNotification) {
        this.settlementInstructionDAO = settlementInstructionDAO;
        this.sendNotification = sendNotification;
    }

    @Autowired
    SettlementInstructionDAO settlementInstructionDAO;

    @Autowired
    SendNotification sendNotification;

    private static final Logger logger = LoggerFactory.getLogger(SettlementInstructionBusinessImpl.class);

    public Boolean validateFutureEffectiveController(SettlementInstruction settlementInstruction){
        return null;
    }

    public Boolean validateModelName(SettlementInstruction settlementInstruction){
        return null;
    }







    public Boolean validateFESICDetailsForUser(String user) throws Exception {

       return null;

    }

    public Boolean validateSettlementDate(SettlementInstruction settlementInstruction) throws ParseException {
       return null;
    }

    public Boolean saveFESICDetails(SettlementInstruction settlementInstruction) throws IssueWhileExecutingQuery {
        return null;
    }

    public Boolean deleteFESICDetails(SettlementInstruction settlementInstruction) throws IssueWhileExecutingQuery {

        return null;
    }

    public Boolean sendNotification(String user) throws Exception {
       return null;
}
}