package com.learn.tdd.dao;

import com.learn.tdd.vo.SettlementInstruction;

public class SettlementInstructionDAOImpl implements SettlementInstructionDAO{
    @Override
    public Boolean findByUserName(String user) throws Exception {
        return null;
    }

    @Override
    public int insert(SettlementInstruction settlementInstruction) throws Exception {
        return 0;
    }

    @Override
    public int delete(SettlementInstruction settlementInstruction) throws Exception {
        return 0;
    }
}
