package com.learn.tdd.service;

import com.learn.tdd.dao.SettlementInstructionDAO;
import com.learn.tdd.dao.SettlementInstructionDAOImpl;
import com.learn.tdd.exception.IssueWhileExecutingQuery;
import com.learn.tdd.helper.Common;
import com.learn.tdd.vo.SettlementInstruction;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.text.ParseException;

import static org.junit.Assert.*;

public class SettlementInstructionBusinessImplTest {

    SettlementInstructionBusinessImpl settlementInstructionBusinessImpl;
    SettlementInstructionDAOImpl settlementInstructionDAO;
    SendNotification sendNotification;
/* As a developer I need to think what actually I need to develop.
1. I need to verify / validate inputted values.
2. Its a Service logic.
3. So I need to create a Service class if it doesnt exists.
4. Instantiate Service class in test class.
5. Now define that method in test class, it will fail/ show error, fix it.
6. As aware we need to define these three inputted values which will be received from frontEnd application.
 */

    @Before
    public void setUp(){
    }

}