package com.learn.tdd;

/**
 * ###############################################################
 * NOTE: WHILE RUNNING THE BELOW TEST CASES,
 * YOU WILL ENCOUNTER COMPILATION ERRORS(Remember the TDD laws).
 * Class file is not created in this project, follow the TDD laws
 * and start executing each test cases one by one.
 * Start developing logic incrementally in class file
 * created while fixing compilation error and making each test cases pass.
 * ###############################################################
 **/ 

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


public class ISBNumValidationTest {
    @Test//This test method is to assert a valid ten digit ISBN Number
    public void checkForValidISBN(){
        ISBNumValidation validate = new ISBNumValidation();
        boolean result = validate.isAnISBNum("0132350882");
        assertTrue(result);
    }
    //Make sure the above Test case fails while you run for first time, then start writing just enough code (as per the 3 rules of TDD), and make the above test case pass using Faking method before implementing any other code

    @Test//This test method is to assert an in-valid ten digit ISBN Number
    public void checkForInValidISBN(){
        ISBNumValidation validate = new ISBNumValidation();
        boolean result = validate.isAnISBNum("0132350883");
        assertFalse(result);
    }
    //Make sure the above Test case fails when you run for first time, then start writing just enough code and make sure the above 2 test cases pass before running the below test case

    @Test(expected = NumberFormatException.class)
    ////This test method is to assert an number format exception if the given ISBN Number is not an ten digit number.
    public void checkForValidTenDigitISBN(){
        ISBNumValidation validate = new ISBNumValidation();
        validate.isAnISBNum("12345678");
    }
    //Make sure the above Test case fails when you run for first time, then start writing just enough code and make sure the above 3 test cases pass before running the below test case

    @Test//This test method is to assert another valid ten digit ISBN Number
    public void checkForAnotherValidISBN(){
        ISBNumValidation validate = new ISBNumValidation();
        boolean result = validate.isAnISBNum("0321146530");
        assertTrue(result);
    }
    //Make sure the above Test case fails when you run for first time, then start writing just enough code and make sure the above 4 test cases pass before running the next test case

    @Test(expected = NumberFormatException.class)
    ////This test method is to assert an number format exception if the given ten digit ISBN Number consists of AlphaNumeric.
    public void checkForInValidAlphaNumericISBN(){
        ISBNumValidation validate = new ISBNumValidation();
        validate.isAnISBNum("ABCDE12345");
    }
    //Make sure all the above Test cases pass before writing any new Test cases
}