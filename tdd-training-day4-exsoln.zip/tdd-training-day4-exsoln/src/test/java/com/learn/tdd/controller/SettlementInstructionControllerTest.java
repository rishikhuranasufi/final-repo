package com.learn.tdd.controller;

import com.learn.tdd.service.SettlementInstructionBusinessImpl;
import com.learn.tdd.vo.SettlementInstruction;
import org.junit.Test;

import org.mockito.Mockito;

import org.springframework.http.ResponseEntity;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

public class SettlementInstructionControllerTest {

    @Test
    public void verifyFutureEffectiveSIControllerWithValidationAsPassed() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        //settlementInstructionController = new SettlementInstructionController(settlementInstructionBusinessImpl);
        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));

        String futureSIController = "abc";
        String modelName = "abc";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);

        Mockito.when(settlementInstructionBusinessImpl
                .validateFutureEffectiveController(settlementInstruction))
                .thenReturn(Boolean.TRUE);

        ResponseEntity<?> response = settlementInstructionController.
                verifyFutureEffectiveController(futureSIController, modelName, date);

        assertEquals(200,response.getStatusCode().value());
    }

    @Test
    public void verifyFutureEffectiveSIControllerWithValidationAsFailed() {
        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);


        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));

        String futureSIController = "abc@@@";
        String modelName = "abc";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);

        Mockito.when(settlementInstructionBusinessImpl
                .validateFutureEffectiveController(settlementInstruction))
                .thenReturn(Boolean.FALSE);

        ResponseEntity<?> response = settlementInstructionController.
                verifyFutureEffectiveController(futureSIController, modelName, date);

        assertEquals(422,response.getStatusCode().value());
    }

    @Test
    public void verifySettlementModelNameWithValidationAsPassed() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        //settlementInstructionController = new SettlementInstructionController(settlementInstructionBusinessImpl);
        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));

        String futureSIController = "abc";
        String modelName = "abc";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);

        Mockito.when(settlementInstructionBusinessImpl
                .validateModelName(settlementInstruction))
                .thenReturn(Boolean.TRUE);

        ResponseEntity<?> response = settlementInstructionController.
                verifySettlementModelName(futureSIController, modelName, date);

        assertEquals(200,response.getStatusCode().value());
    }

    @Test
    public void verifySettlementModelNameWithValidationAsFailed() {
        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);


        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));

        String futureSIController = "abc@@@";
        String modelName = "abc";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);

        Mockito.when(settlementInstructionBusinessImpl
                .validateModelName(settlementInstruction))
                .thenReturn(Boolean.FALSE);

        ResponseEntity<?> response = settlementInstructionController.
                verifySettlementModelName(futureSIController, modelName, date);

        assertEquals(422,response.getStatusCode().value());
    }

    @Test
    public void verifyWhenFESICDetailsAvailableForUser() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        //settlementInstructionController = new SettlementInstructionController(settlementInstructionBusinessImpl);
        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String user = "demoUser";
        Mockito.when(settlementInstructionBusinessImpl
                .validateFESICDetailsForUser(user))
                .thenReturn(Boolean.TRUE);

        ResponseEntity<?> response = settlementInstructionController.
                validateFESICDetailsAvailability(user);

        assertEquals(200,response.getStatusCode().value());
    }

    @Test
    public void verifyWhenFESICDetailsNOTAvailableForUser() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String user = "demoUserWithoutFESIC";
        Mockito.when(settlementInstructionBusinessImpl
                .validateFESICDetailsForUser(user))
                .thenReturn(Boolean.FALSE);

        ResponseEntity<?> response = settlementInstructionController.
                validateFESICDetailsAvailability(user);

        assertEquals(422,response.getStatusCode().value());
    }

    @Test
    public void verifySettlementDate() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        //settlementInstructionController = new SettlementInstructionController(settlementInstructionBusinessImpl);
        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String futureSIController = "abc@@@";
        String modelName = "abc";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);
        Mockito.when(settlementInstructionBusinessImpl
                .validateSettlementDate(settlementInstruction))
                .thenReturn(Boolean.TRUE);

        ResponseEntity<?> response = settlementInstructionController.
                verifySettlementDate(futureSIController, modelName, date);

        assertEquals(200,response.getStatusCode().value());
    }

    @Test
    public void verifySettlementDateWithFalse() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String futureSIController = "abc@@@";
        String modelName = "abc";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);
        Mockito.when(settlementInstructionBusinessImpl
                .validateSettlementDate(settlementInstruction))
                .thenReturn(Boolean.FALSE);

        ResponseEntity<?> response = settlementInstructionController.
                verifySettlementDate(futureSIController, modelName, date);

        assertEquals(422,response.getStatusCode().value());
    }

    @Test
    public void saveFESICDetailsWithSuccess() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        //settlementInstructionController = new SettlementInstructionController(settlementInstructionBusinessImpl);
        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String futureSIController = "abcTest";
        String modelName = "abc123";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);
        Mockito.when(settlementInstructionBusinessImpl
                .saveFESICDetails(settlementInstruction))
                .thenReturn(Boolean.TRUE);

        ResponseEntity<?> response = settlementInstructionController.
                saveFESICDetails(futureSIController, modelName, date);

        assertEquals(200,response.getStatusCode().value());
    }

    @Test
    public void saveFESICDetailsWithFailure() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String futureSIController = "abcTest";
        String modelName = "abcTest123";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);
        Mockito.when(settlementInstructionBusinessImpl
                .saveFESICDetails(settlementInstruction))
                .thenReturn(Boolean.FALSE);

        ResponseEntity<?> response = settlementInstructionController.
                saveFESICDetails(futureSIController, modelName, date);

        assertEquals(422,response.getStatusCode().value());
    }

    @Test
    public void deleteFESICDetailsWithSuccess() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        //settlementInstructionController = new SettlementInstructionController(settlementInstructionBusinessImpl);
        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String futureSIController = "abcTest";
        String modelName = "abc123";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);
        Mockito.when(settlementInstructionBusinessImpl
                .deleteFESICDetails(settlementInstruction))
                .thenReturn(Boolean.TRUE);

        ResponseEntity<?> response = settlementInstructionController.
                deleteFESICDetails(futureSIController, modelName, date);

        assertEquals(200,response.getStatusCode().value());
    }

    @Test
    public void deleteFESICDetailsWithFailure() throws Exception {

        SettlementInstructionBusinessImpl settlementInstructionBusinessImpl =
                Mockito.mock(SettlementInstructionBusinessImpl.class);

        SettlementInstructionController settlementInstructionController
                = Mockito.spy(new SettlementInstructionController(settlementInstructionBusinessImpl));
        String futureSIController = "abcTest";
        String modelName = "abcTest123";
        String date = "date";

        SettlementInstruction settlementInstruction =
                mock(SettlementInstruction.class);

        Mockito.doReturn(settlementInstruction).when(settlementInstructionController).
                getSettlementInstruction(futureSIController,modelName,date);
        Mockito.when(settlementInstructionBusinessImpl
                .deleteFESICDetails(settlementInstruction))
                .thenReturn(Boolean.FALSE);

        ResponseEntity<?> response = settlementInstructionController.
                deleteFESICDetails(futureSIController, modelName, date);

        assertEquals(422,response.getStatusCode().value());
    }
}