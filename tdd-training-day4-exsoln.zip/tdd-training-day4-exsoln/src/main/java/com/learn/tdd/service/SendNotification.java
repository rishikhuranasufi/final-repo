package com.learn.tdd.service;

public interface SendNotification {

    Boolean sendNotification(String user) throws Exception;
}
