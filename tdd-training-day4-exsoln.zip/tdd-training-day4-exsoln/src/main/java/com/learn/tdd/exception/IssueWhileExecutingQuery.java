package com.learn.tdd.exception;

public class IssueWhileExecutingQuery extends Exception{
}
